require('./bootstrap');

window.Vue = require('vue');
window.flatpickr = require('flatpickr');
window.flatpickrRU = require("flatpickr/dist/l10n/ru.js").default.ru;
