@extends('layouts.admin')

@section('content')
    <h1>Главная страница админки</h1>
@endsection
